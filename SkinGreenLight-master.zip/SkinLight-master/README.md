LightSkin für IP-Symcon WebFront

Version 1.0  

* Benötigt: IP-Symcon 5.0 oder neuer
* Größe: 7.0 MB
* Farbton: weiß/grau

Icons Copyright: Symcon GmbH

Die Icons sind ausschließlich für die Nutzung in diesem Skin bestimmt. Die Verbreitung, Bearbeitung, oder Nutzung der Icons außerhalb dieses Skins ist ausdrücklich untersagt.